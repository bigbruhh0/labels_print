from reportlab.lib.colors import red
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import cm
from reportlab.pdfgen.canvas import Canvas
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_JUSTIFY, TA_LEFT, TA_CENTER, TA_RIGHT
import subprocess
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfgen.canvas import Canvas
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.fonts import addMapping
from reportlab.pdfbase.ttfonts import TTFont

pdfmetrics.registerFont(TTFont('shop_font', 'shop_font.ttf'))
pdfmetrics.registerFont(TTFont('frag_font', 'frag_font.ttf'))
def get_height(font_list):
	string_height=0
	for i in font_list:
		face = pdfmetrics.getFont(i[0]).face
		string_height += (face.ascent - face.descent) / 1000 * i[1]
	return string_height
#addMapping('sh_n_font', 0, 0, 'shop_font.ttf')  # 'MyFont' - имя шрифта, 'myfont.ttf' - путь к файлу шрифта

shop_font=['shop_font',7]
conc_font=['Times-Roman',5]
frag_font=['frag_font',9]
brand_font=['frag_font',6]
my_style=ParagraphStyle('style1',
	fontName='Times-Roman',
	fontSize=shop_font[1],
	#backColor="#FFFF00",
	wordWrap = TA_JUSTIFY,
	alignment=TA_CENTER,
	borderPadding=0,
	leftIndent=0,
	rightIndent=0,
	spaceAfter=0,
	spaceBefore=0,
	splitLongWords=True,
	spaceShrinkage=0.05,
	#textTransform='uppercase'
	underlineWidth=0,
	underlineOffset=0,
	underlineGap=0,
	leading=6,
	)
conc_style=ParagraphStyle('style1',
	fontName='Times-Roman',
	fontSize=shop_font[1],
	#backColor="#FFFF00",
	wordWrap = TA_JUSTIFY,
	alignment=TA_CENTER,
	borderPadding=0,
	leftIndent=0,
	rightIndent=0,
	spaceAfter=0,
	spaceBefore=0,
	splitLongWords=True,
	spaceShrinkage=0.05,
	#textTransform='uppercase'
	underlineWidth=0,
	underlineOffset=0,
	underlineGap=0,
	leading=6,
	font_weigth='bold'
	)
brand_style=ParagraphStyle('style1',
	fontName=frag_font[0],
	fontSize=brand_font[1],
	wordWrap = TA_JUSTIFY,
	alignment=TA_CENTER,
	borderPadding=0,
	leftIndent=0,
	rightIndent=0,
	spaceAfter=0,
	spaceBefore=0,
	splitLongWords=True,
	spaceShrinkage=0.05,
	#textTransform='uppercase'
	underlineWidth=0,
	underlineOffset=0,
	underlineGap=0,
	leading=7,
	)
frag_style=ParagraphStyle('style1',
	fontName=frag_font[0],
	fontSize=frag_font[1],
	#backColor="#FFFF00",
	wordWrap = TA_JUSTIFY,
	alignment=TA_CENTER,
	borderPadding=0,
	leftIndent=0,
	rightIndent=0,
	spaceAfter=0,
	spaceBefore=0,
	splitLongWords=True,
	spaceShrinkage=0.05,
	#textTransform='uppercase'
	underlineWidth=0,
	underlineOffset=0,
	underlineGap=0,
	leading=7,
	)
shop_style=my_style
shop_style.fontName=shop_font[0]
shop_style.fontSize=shop_font[1]

brand_name = "Histories de Parfums"
frag_name = "1828 JULES VERNE"
conc = "edp"
ml = "2"
shop_name="Аллюрпарфюм"
width = 2.5 * cm
height = 1.8 * cm

c = Canvas("test.pdf", pagesize=(width,height))

c.rect(0.18*cm,0.1*cm, 2.28*cm, 1.65*cm)

p1 = Paragraph(shop_name,shop_style)
p1.wrapOn(c, 2.28 * cm, 0.0 * cm)
p1.drawOn(c, 0.18 * cm, 0.2 * cm)

p2 = Paragraph(conc+' '+ml+' ml',conc_style)
p2.wrapOn(c, 2.28 * cm, 0.0 * cm)
p2.drawOn(c, 0.18 * cm, 0.2 * cm+get_height([shop_font])*1.2)



p4 = Paragraph(brand_name,brand_style)
p4.wrapOn(c, 2.28 * cm, 0.0 * cm)
p4.drawOn(c, 0.18 * cm, 1.5*cm-get_height([brand_font])*.8)


p3 = Paragraph(frag_name,frag_style)
p3.wrapOn(c, 2.28 * cm, 0.0 * cm)
p3.drawOn(c, 0.18 * cm, 0.4 * cm+get_height([shop_font,conc_font])*1)
c.save()

# Open the generated PDF using default PDF viewer
subprocess.Popen(["start", "", "test.pdf"], shell=True)
